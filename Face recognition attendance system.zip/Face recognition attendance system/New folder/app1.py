import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime
from PIL import ImageGrab
from twilio.rest import Client
import tkinter as tk
from tkinter import messagebox
import threading

# Twilio credentials
account_sid = 'AC62c6f0c56d2fc4c183080b2f526da5eb'
auth_token = '4f6914170211f805632f70fec777b649'
twilio_phone_number = '+15855232560'
receiver_phone_number = '+918248404078'

# Path to image folder
path = 'C:/Users/DELL/Downloads/face atten run/New folder/image_folder'

# Load images and names
images = []
classNames = []
myList = os.listdir(path)
for cl in myList:
    curImg = cv2.imread(f'{path}/{cl}')
    images.append(curImg)
    classNames.append(os.path.splitext(cl)[0])

# Encode known faces
def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList

# Mark attendance
markedStudents = []
def markAttendance(name):
    global markedStudents
    with open('C:/Users/DELL/Downloads/face atten run/New folder/attendance/Attendance.csv', 'a+') as f:
        myDataList = f.readlines()
        nameList = []
        for line in myDataList:
            entry = line.split(',')
            nameList.append(entry[0])
        if name not in nameList and name not in markedStudents:
            markedStudents.append(name)
            now = datetime.now()
            date_string = now.strftime('%Y-%m-%d')
            time_string = now.strftime('%H:%M:%S')
            day_of_week = now.strftime('%A')
            f.seek(0, 2)
            f.writelines(f'\n{name},{date_string},{time_string},{day_of_week}')
            # Send message to Twilio number
            client = Client(account_sid, auth_token)
            message = client.messages.create(
                body=f"{name} has been marked as present on {day_of_week}, {date_string}.",
                from_=twilio_phone_number,
                to=receiver_phone_number
            )

# Encode known faces
encodeListKnown = findEncodings(images)
print('Encoding Complete')

# Create the GUI
def record_attendance():
    global cap
    # Capture video stream
    cap = cv2.VideoCapture(0)
    no_faces_timer = 0
    while True:
        success, img = cap.read()
        if success:
            imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
            imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)
            facesCurFrame = face_recognition.face_locations(imgS)
            encodesCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

            if len(facesCurFrame) == 0:
                no_faces_timer += 1
                if no_faces_timer > 400:  # no faces detected for more than 20 seconds
                    cap.release()
                    cv2.destroyAllWindows()
                    messagebox.showwarning("Attendance Recording Error", "No faces were detected in the video stream.")
                    break
            else:
                no_faces_timer = 0

            for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
                matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
                faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
                matchIndex = np.argmin(faceDis)
                if matches[matchIndex]:
                    name = classNames[matchIndex].upper()
                    y1, x2, y2, x1 = faceLoc
                    y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                    cv2.rectangle(img, (x1, y2 - 35), (x2, y2), (0, 255, 0), cv2.FILLED)
                    cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                    markAttendance(name)
                else:
                    name = "Unknown"
                    y1, x2, y2, x1 = faceLoc
                    y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                    cv2.rectangle(img, (x1, y2 - 35), (x2, y2), (0, 0, 255), cv2.FILLED)
                    cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                    markAttendance(name)
                    now = datetime.now()
                    date_string = now.strftime('%Y-%m-%d_%H-%M-%S')
                    img_name = f'unknown_{date_string}.jpg'
                    img_path = os.path.join('unknown_faces', img_name)
                    cv2.imwrite(img_path, img)
                    client = Client(account_sid, auth_token)
                    message = client.messages.create(
                        body=f"Unknown person has been detected on {day_of_week}, {date_string}.",
                        from_=twilio_phone_number,
                        to=receiver_phone_number,
                        media_url=[f'https://myserver.com/{img_path}']
                        )
                    def show_popup():
                        popup = tk.Toplevel()
                        popup.title('Unknown Person Detected')
                        img = ImageGrab.grab(bbox=(100, 100, 500, 500))  # capture a screenshot of the screen
                        img = np.array(img)
                        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                        img = cv2.resize(img, (500, 500))
                        img = Image.fromarray(img)
                        img = img.save(f'temp/{img_name}')
                        img = tk.PhotoImage(file=f'temp/{img_name}')
                        label = tk.Label(popup, image=img)
                        label.image = img
                        label.pack(padx=10, pady=10)
                        popup.mainloop()
                        threading.Thread(target=show_popup).start()
                        cv2.imshow('Webcam', img)
                    if cv2.waitKey(1) == ord('q'):
                            break
                    else:
                            break

    cap.release()
    cv2.destroyAllWindows()

